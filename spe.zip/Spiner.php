<?

/*****************************************
** Decryption Provided By Spiner         *
**                                       *
** Contatct : yamhisse@gmail.com         *
******************************************/

/* Enter The php Encoded By XBOOMBER Here:

					 ||
					\\//
					 \/
*/

		$F_Name = 'xb.php';

include('lib/SPE.php');

$SP = new Spiner();

$SP->decode($F_Name);

?>